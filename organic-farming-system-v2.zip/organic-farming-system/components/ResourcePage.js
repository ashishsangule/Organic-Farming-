"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/components/Providers";
import { Button, Empty, ErrorNote, Label, Spinner, inputCls } from "@/components/ui";

/**
 * Generic list + add form for one Supabase table.
 * fields: [{ name, label, type: text|number|date|select|textarea, required, options, ref:{table,label}, defaultValue }]
 * card(row) => { title, lines: string[], badge? }
 * statusField: { name, options } -> inline status picker on each card
 */
export default function ResourcePage({ table, title, singular, select = "*", fields, card, statusField, orderBy = "created_at", ascending = false, emptyHint }) {
  const { user } = useAuth();
  const [rows, setRows] = useState(null);
  const [refs, setRefs] = useState({});
  const [error, setError] = useState("");
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState("");

  const load = useCallback(async () => {
    const { data, error } = await supabase.from(table).select(select).order(orderBy, { ascending });
    if (error) setError(error.message); else { setError(""); setRows(data); }
  }, [table, select, orderBy, ascending]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const refFields = fields.filter((f) => f.ref);
    Promise.all(refFields.map(async (f) => {
      const { data } = await supabase.from(f.ref.table).select(`id, ${f.ref.label}`).order("created_at", { ascending: false });
      return [f.name, (data || []).map((r) => ({ value: r.id, label: r[f.ref.label] }))];
    })).then((pairs) => setRefs(Object.fromEntries(pairs)));
  }, [fields]);

  const shown = useMemo(() => {
    if (!rows) return null;
    const s = q.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter((r) => JSON.stringify(r).toLowerCase().includes(s));
  }, [rows, q]);

  async function onAdd(e) {
    e.preventDefault();
    setBusy(true); setError("");
    const f = new FormData(e.currentTarget);
    const payload = { user_id: user.id };
    for (const fd of fields) {
      let v = f.get(fd.name);
      if (v === "" || v === null) v = null;
      else if (fd.type === "number" || fd.ref) v = Number(v);
      payload[fd.name] = v;
    }
    const { error } = await supabase.from(table).insert(payload);
    setBusy(false);
    if (error) { setError(error.message); return; }
    e.target.reset(); setOpen(false); load();
  }

  async function onDelete(id) {
    if (!confirm(`Delete this ${singular}? This cannot be undone.`)) return;
    const { error } = await supabase.from(table).delete().eq("id", id);
    if (error) setError(error.message); else load();
  }

  async function onStatus(id, value) {
    const { error } = await supabase.from(table).update({ [statusField.name]: value }).eq("id", id);
    if (error) setError(error.message); else load();
  }

  const missingRef = fields.find((f) => f.ref && refs[f.name] && refs[f.name].length === 0);

  return (
    <section>
      <div className="mb-4 flex items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-extrabold">{title}</h1>
        <Button onClick={() => setOpen((o) => !o)} aria-expanded={open}>{open ? "Close" : `Add ${singular}`}</Button>
      </div>

      {open && (
        missingRef ? (
          <div className="mb-4"><Empty title={`Add a ${missingRef.ref.table.replace(/s$/, "")} first`} hint={`You need at least one before adding a ${singular}.`} /></div>
        ) : (
          <form onSubmit={onAdd} className="mb-5 space-y-3 rounded-2xl border border-line bg-white p-4">
            {fields.map((fd) => (
              <div key={fd.name}>
                <Label htmlFor={fd.name}>{fd.label}{fd.required ? " *" : ""}</Label>
                {fd.type === "textarea" ? (
                  <textarea id={fd.name} name={fd.name} rows={3} required={fd.required} className={inputCls} />
                ) : fd.type === "select" || fd.ref ? (
                  <select id={fd.name} name={fd.name} required={fd.required} defaultValue={fd.defaultValue ?? ""} className={inputCls}>
                    <option value="" disabled={fd.required}>{fd.required ? "Choose…" : "None"}</option>
                    {(fd.ref ? refs[fd.name] || [] : fd.options.map((o) => ({ value: o, label: o }))).map((o) => (
                      <option key={o.value} value={o.value}>{o.label}</option>
                    ))}
                  </select>
                ) : (
                  <input id={fd.name} name={fd.name} type={fd.type || "text"} required={fd.required}
                    step={fd.type === "number" ? "any" : undefined} inputMode={fd.type === "number" ? "decimal" : undefined}
                    min={fd.type === "number" ? 0 : undefined} defaultValue={fd.defaultValue ?? ""} className={inputCls} />
                )}
              </div>
            ))}
            <Button type="submit" disabled={busy} className="w-full">{busy ? "Saving…" : `Save ${singular}`}</Button>
          </form>
        )
      )}

      <ErrorNote>{error}</ErrorNote>

      {rows && rows.length > 4 && (
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Search ${title.toLowerCase()}`}
          aria-label={`Search ${title}`} className={`${inputCls} mb-4`} />
      )}

      {shown === null ? (
        <div className="grid place-items-center py-16"><Spinner /></div>
      ) : shown.length === 0 ? (
        <Empty title={q ? "No matches" : `No ${title.toLowerCase()} yet`} hint={q ? "Try a different search." : emptyHint} />
      ) : (
        <ul className="space-y-3">
          {shown.map((r) => {
            const c = card(r);
            return (
              <li key={r.id} className="rounded-2xl border border-line bg-white p-4">
                <div className="flex items-start justify-between gap-3">
                  <h2 className="min-w-0 break-words font-display text-lg font-bold">{c.title}</h2>
                  {c.badge}
                </div>
                {c.lines.filter(Boolean).map((l, i) => <p key={i} className="mt-1 break-words text-sm text-ink/75">{l}</p>)}
                <div className="mt-3 flex items-center justify-between gap-3">
                  {statusField ? (
                    <select aria-label="Status" value={r[statusField.name] || ""} onChange={(e) => onStatus(r.id, e.target.value)} className={`${inputCls} max-w-44`}>
                      {statusField.options.map((o) => <option key={o}>{o}</option>)}
                    </select>
                  ) : <span />}
                  <Button variant="danger" onClick={() => onDelete(r.id)} aria-label={`Delete ${singular}`}>Delete</Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
