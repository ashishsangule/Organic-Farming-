export function Spinner() {
  return <div role="status" aria-label="Loading" className="h-8 w-8 animate-spin rounded-full border-4 border-sprout border-t-leaf" />;
}

export function Button({ variant = "primary", className = "", ...props }) {
  const styles = {
    primary: "bg-leaf text-white hover:bg-leaf-dark disabled:opacity-60",
    ghost: "bg-white text-ink border border-line hover:bg-sprout",
    danger: "bg-white text-danger border border-line hover:bg-red-50",
  };
  return (
    <button
      className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 font-semibold transition-colors ${styles[variant]} ${className}`}
      {...props}
    />
  );
}

export const inputCls =
  "min-h-11 w-full rounded-xl border border-line bg-white px-3 py-2 text-ink placeholder:text-ink/40";

export function Label({ children, htmlFor }) {
  return <label htmlFor={htmlFor} className="mb-1 block text-sm font-semibold text-ink/80">{children}</label>;
}

export function Empty({ title, hint }) {
  return (
    <div className="rounded-2xl border border-dashed border-line bg-white/60 p-8 text-center">
      <p className="font-display text-lg font-semibold">{title}</p>
      {hint && <p className="mt-1 text-sm text-ink/70">{hint}</p>}
    </div>
  );
}

export function ErrorNote({ children }) {
  if (!children) return null;
  return <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-danger">{children}</p>;
}

export function Badge({ children, tone = "leaf" }) {
  const tones = { leaf: "bg-sprout text-leaf-dark", sun: "bg-amber-100 text-amber-900", soil: "bg-stone-200 text-soil" };
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${tones[tone]}`}>{children}</span>;
}
