"use client";
import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { Button, ErrorNote, Label, inputCls } from "@/components/ui";

export default function AuthForm() {
  const [mode, setMode] = useState("signin");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setBusy(true); setError(""); setInfo("");
    const f = new FormData(e.currentTarget);
    const email = f.get("email").trim();
    const password = f.get("password");
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { data, error } = await supabase.auth.signUp({
          email, password,
          options: { data: { full_name: f.get("full_name")?.trim() } },
        });
        if (error) throw error;
        if (!data.session) setInfo("Check your email to confirm your account, then sign in.");
      }
    } catch (err) {
      setError(err.message || "Something went wrong. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-5 py-10 pt-safe pb-safe">
      <div className="mb-8">
        <div className="mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-leaf text-3xl" aria-hidden>🌱</div>
        <h1 className="font-display text-3xl font-extrabold leading-tight">Organic Farming System</h1>
        <p className="mt-2 text-ink/75">Keep every farm, field, crop and rupee in one place. Works on any phone.</p>
      </div>
      <form onSubmit={onSubmit} className="space-y-4">
        {mode === "signup" && (
          <div>
            <Label htmlFor="full_name">Full name</Label>
            <input id="full_name" name="full_name" required autoComplete="name" className={inputCls} />
          </div>
        )}
        <div>
          <Label htmlFor="email">Email</Label>
          <input id="email" name="email" type="email" required autoComplete="email" inputMode="email" className={inputCls} />
        </div>
        <div>
          <Label htmlFor="password">Password</Label>
          <input id="password" name="password" type="password" required minLength={6}
            autoComplete={mode === "signin" ? "current-password" : "new-password"} className={inputCls} />
        </div>
        <ErrorNote>{error}</ErrorNote>
        {info && <p className="rounded-xl bg-sprout p-3 text-sm text-leaf-dark">{info}</p>}
        <Button type="submit" disabled={busy} className="w-full">
          {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
        </Button>
      </form>
      <button
        onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(""); setInfo(""); }}
        className="mt-5 min-h-11 text-center font-semibold text-leaf underline"
      >
        {mode === "signin" ? "New here? Create an account" : "Have an account? Sign in"}
      </button>
    </main>
  );
}
