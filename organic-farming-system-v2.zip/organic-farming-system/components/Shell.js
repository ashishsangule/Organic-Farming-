"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/components/Providers";

export const NAV = [
  { href: "/", label: "Home", icon: "🏡" },
  { href: "/farms", label: "Farms", icon: "🌾" },
  { href: "/fields", label: "Fields", icon: "🟫" },
  { href: "/crops", label: "Crops", icon: "🌱" },
  { href: "/tasks", label: "Tasks", icon: "✅" },
  { href: "/activities", label: "Activities", icon: "🚜" },
  { href: "/harvests", label: "Harvests", icon: "🧺" },
  { href: "/expenses", label: "Expenses", icon: "💰" },
];
const TABS = NAV.slice(0, 5);

const active = (path, href) => (href === "/" ? path === "/" : path.startsWith(href));

export default function Shell({ children }) {
  const path = usePathname();
  const { signOut } = useAuth();
  return (
    <div className="min-h-dvh md:grid md:grid-cols-[15rem_1fr]">
      {/* Desktop sidebar */}
      <aside className="hidden border-r border-line bg-white md:flex md:flex-col md:p-4">
        <p className="mb-6 px-2 font-display text-xl font-extrabold text-leaf-dark">🌱 Organic Farm</p>
        <nav className="flex flex-col gap-1">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href}
              className={`flex min-h-11 items-center gap-3 rounded-xl px-3 font-semibold ${active(path, n.href) ? "bg-sprout text-leaf-dark" : "hover:bg-chalk"}`}>
              <span aria-hidden>{n.icon}</span>{n.label}
            </Link>
          ))}
        </nav>
        <button onClick={signOut} className="mt-auto min-h-11 rounded-xl px-3 text-left font-semibold text-danger hover:bg-red-50">Sign out</button>
      </aside>

      <div className="min-w-0">
        <header className="sticky top-0 z-20 border-b border-line bg-leaf pt-safe text-white md:hidden">
          <div className="flex h-12 items-center justify-between px-4">
            <span className="font-display font-extrabold">🌱 Organic Farm</span>
            <Link href="/more" className="min-h-11 content-center px-2 text-sm font-semibold underline">More</Link>
          </div>
        </header>
        <main className="mx-auto w-full max-w-3xl px-4 py-5 pb-28 md:pb-10">{children}</main>
      </div>

      {/* Mobile bottom tab bar */}
      <nav aria-label="Main" className="pb-safe fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white md:hidden">
        <ul className="grid grid-cols-5">
          {TABS.map((n) => (
            <li key={n.href}>
              <Link href={n.href}
                className={`flex min-h-14 flex-col items-center justify-center text-xs font-semibold ${active(path, n.href) ? "text-leaf-dark" : "text-ink/60"}`}>
                <span className={`rounded-full px-4 py-0.5 text-lg ${active(path, n.href) ? "bg-sprout" : ""}`} aria-hidden>{n.icon}</span>
                {n.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
