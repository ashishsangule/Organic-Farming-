"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { supabase, supabaseConfigured } from "@/lib/supabase";
import Shell from "@/components/Shell";
import AuthForm from "@/components/AuthForm";
import { Spinner } from "@/components/ui";

const AuthCtx = createContext({ user: null, signOut: () => {} });
export const useAuth = () => useContext(AuthCtx);

export default function Providers({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!supabase) { setReady(true); return; }
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user ?? null);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const signOut = () => supabase?.auth.signOut();

  if (!supabaseConfigured) {
    return (
      <main className="mx-auto max-w-md p-6 pt-safe">
        <h1 className="font-display text-2xl font-bold">Setup needed</h1>
        <p className="mt-2 text-ink/80">
          Add <code>NEXT_PUBLIC_SUPABASE_URL</code> and <code>NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY</code> in
          your Vercel project settings (Environment Variables), then redeploy.
        </p>
      </main>
    );
  }
  if (!ready) return <div className="grid min-h-dvh place-items-center"><Spinner /></div>;
  if (!user) return <AuthForm />;

  return (
    <AuthCtx.Provider value={{ user, signOut }}>
      <Shell>{children}</Shell>
    </AuthCtx.Provider>
  );
}
