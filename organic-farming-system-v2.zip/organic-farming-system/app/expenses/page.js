"use client";
import ResourcePage from "@/components/ResourcePage";

const today = new Date().toISOString().slice(0, 10);
const fields = [
  { name: "farm_id", label: "Farm", required: true, ref: { table: "farms", label: "farm_name" } },
  { name: "category", label: "Category", required: true, type: "select", options: ["Seeds", "Compost & manure", "Labour", "Irrigation", "Equipment", "Transport", "Other"] },
  { name: "amount", label: "Amount (₹)", type: "number", required: true },
  { name: "expense_date", label: "Date", type: "date", defaultValue: today },
  { name: "notes", label: "Notes", type: "textarea" },
];

export default function Page() {
  return (
    <ResourcePage table="expenses" title="Expenses" singular="expense" select="*, farms(farm_name)" fields={fields}
      orderBy="expense_date" emptyHint="Track what you spend so you can see profit later."
      card={(r) => ({ title: `₹${Number(r.amount).toLocaleString("en-IN")} · ${r.category}`, lines: [r.farms?.farm_name && `Farm: ${r.farms.farm_name}`, r.expense_date, r.notes] })} />
  );
}
