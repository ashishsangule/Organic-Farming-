"use client";
import ResourcePage from "@/components/ResourcePage";
import { Badge } from "@/components/ui";

const STATUS = ["Pending", "In progress", "Done"];
const fields = [
  { name: "task_name", label: "Task", required: true },
  { name: "description", label: "Details", type: "textarea" },
  { name: "due_date", label: "Due date", type: "date" },
  { name: "status", label: "Status", type: "select", options: STATUS, defaultValue: "Pending" },
];

export default function Page() {
  return (
    <ResourcePage table="tasks" title="Tasks" singular="task" fields={fields} statusField={{ name: "status", options: STATUS }}
      orderBy="due_date" ascending emptyHint="Add reminders like watering, spraying or market day."
      card={(r) => ({ title: r.task_name, badge: r.due_date && <Badge tone="sun">Due {r.due_date}</Badge>, lines: [r.description] })} />
  );
}
