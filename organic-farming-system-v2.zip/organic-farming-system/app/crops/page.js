"use client";
import ResourcePage from "@/components/ResourcePage";
import { Badge } from "@/components/ui";

const STATUS = ["Planned", "Growing", "Harvested", "Failed"];
const fields = [
  { name: "field_id", label: "Field", required: true, ref: { table: "fields", label: "field_name" } },
  { name: "crop_name", label: "Crop", required: true },
  { name: "variety", label: "Variety" },
  { name: "planting_date", label: "Planting date", type: "date" },
  { name: "expected_harvest", label: "Expected harvest", type: "date" },
  { name: "status", label: "Status", type: "select", options: STATUS, defaultValue: "Growing" },
];

export default function Page() {
  return (
    <ResourcePage table="crops" title="Crops" singular="crop" select="*, fields(field_name)" fields={fields}
      statusField={{ name: "status", options: STATUS }} emptyHint="Add a field first, then record what you plant."
      card={(r) => ({
        title: r.crop_name, badge: r.status && <Badge tone={r.status === "Failed" ? "soil" : "leaf"}>{r.status}</Badge>,
        lines: [r.variety && `Variety: ${r.variety}`, r.fields?.field_name && `Field: ${r.fields.field_name}`,
          r.planting_date && `Planted ${r.planting_date}`, r.expected_harvest && `Harvest by ${r.expected_harvest}`],
      })} />
  );
}
