"use client";
import ResourcePage from "@/components/ResourcePage";

const today = new Date().toISOString().slice(0, 10);
const fields = [
  { name: "field_id", label: "Field", required: true, ref: { table: "fields", label: "field_name" } },
  { name: "activity", label: "Activity", required: true, type: "select", options: ["Ploughing", "Sowing", "Irrigation", "Weeding", "Composting", "Pest control", "Mulching", "Other"] },
  { name: "activity_date", label: "Date", type: "date", defaultValue: today },
  { name: "notes", label: "Notes", type: "textarea" },
];

export default function Page() {
  return (
    <ResourcePage table="activities" title="Activities" singular="activity" select="*, fields(field_name)" fields={fields}
      orderBy="activity_date" emptyHint="Log work done in your fields."
      card={(r) => ({ title: r.activity, lines: [r.fields?.field_name && `Field: ${r.fields.field_name}`, r.activity_date, r.notes] })} />
  );
}
