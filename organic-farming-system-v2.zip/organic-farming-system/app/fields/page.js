"use client";
import ResourcePage from "@/components/ResourcePage";

const fields = [
  { name: "farm_id", label: "Farm", required: true, ref: { table: "farms", label: "farm_name" } },
  { name: "field_name", label: "Field name", required: true },
  { name: "area", label: "Area (acres)", type: "number" },
  { name: "soil_type", label: "Soil type", type: "select", options: ["Loam", "Clay", "Sandy", "Silt", "Black cotton", "Red", "Laterite"] },
];

export default function Page() {
  return (
    <ResourcePage table="fields" title="Fields" singular="field" select="*, farms(farm_name)" fields={fields}
      emptyHint="Fields are plots inside a farm."
      card={(r) => ({ title: r.field_name, lines: [r.farms?.farm_name && `Farm: ${r.farms.farm_name}`, r.area != null && `${r.area} acres`, r.soil_type && `Soil: ${r.soil_type}`] })} />
  );
}
