export default function manifest() {
  return {
    name: "Organic Farming System",
    short_name: "Organic Farm",
    description: "Manage farms, fields, crops, tasks, harvests and expenses.",
    start_url: "/",
    display: "standalone",
    background_color: "#f3f6f1",
    theme_color: "#2e6a3b",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" }],
  };
}
