"use client";
import ResourcePage from "@/components/ResourcePage";

const today = new Date().toISOString().slice(0, 10);
const fields = [
  { name: "crop_id", label: "Crop", required: true, ref: { table: "crops", label: "crop_name" } },
  { name: "quantity", label: "Quantity", type: "number", required: true },
  { name: "unit", label: "Unit", type: "select", options: ["kg", "quintal", "tonne", "bags", "crates"], defaultValue: "kg" },
  { name: "harvest_date", label: "Harvest date", type: "date", defaultValue: today },
];

export default function Page() {
  return (
    <ResourcePage table="harvests" title="Harvests" singular="harvest" select="*, crops(crop_name)" fields={fields}
      orderBy="harvest_date" emptyHint="Record what you bring in from each crop."
      card={(r) => ({ title: `${r.quantity} ${r.unit || ""}`, lines: [r.crops?.crop_name && `Crop: ${r.crops.crop_name}`, r.harvest_date] })} />
  );
}
