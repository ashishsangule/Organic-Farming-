import { Bricolage_Grotesque, Source_Sans_3 } from "next/font/google";
import "./globals.css";
import Providers from "@/components/Providers";

const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const body = Source_Sans_3({ subsets: ["latin"], variable: "--font-body", display: "swap" });

export const metadata = {
  title: { default: "Organic Farming System", template: "%s · Organic Farming System" },
  description: "Manage your farms, fields, crops, tasks, harvests and expenses from any phone.",
  applicationName: "Organic Farming System",
  appleWebApp: { capable: true, title: "Organic Farm", statusBarStyle: "default" },
  formatDetection: { telephone: false },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#2e6a3b",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
