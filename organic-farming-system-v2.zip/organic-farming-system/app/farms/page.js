"use client";
import ResourcePage from "@/components/ResourcePage";

const fields = [
  { name: "farm_name", label: "Farm name", required: true },
  { name: "location", label: "Location" },
  { name: "total_area", label: "Total area (acres)", type: "number" },
];

export default function Page() {
  return (
    <ResourcePage table="farms" title="Farms" singular="farm" fields={fields}
      emptyHint="Add your first farm to start tracking fields and crops."
      card={(r) => ({ title: r.farm_name, lines: [r.location && `📍 ${r.location}`, r.total_area != null && `${r.total_area} acres`] })} />
  );
}
