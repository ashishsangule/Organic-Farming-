"use client";
import Link from "next/link";
import { NAV } from "@/components/Shell";
import { useAuth } from "@/components/Providers";
import { Button } from "@/components/ui";

export default function Page() {
  const { user, signOut } = useAuth();
  return (
    <section>
      <h1 className="mb-1 font-display text-2xl font-extrabold">More</h1>
      <p className="mb-4 break-words text-sm text-ink/70">Signed in as {user.email}</p>
      <ul className="space-y-2">
        {NAV.slice(5).map((n) => (
          <li key={n.href}>
            <Link href={n.href} className="flex min-h-12 items-center gap-3 rounded-xl border border-line bg-white px-4 font-semibold">
              <span aria-hidden>{n.icon}</span>{n.label}
            </Link>
          </li>
        ))}
      </ul>
      <Button variant="danger" onClick={signOut} className="mt-6 w-full">Sign out</Button>
    </section>
  );
}
