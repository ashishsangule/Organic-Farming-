"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { Empty, ErrorNote, Spinner } from "@/components/ui";

const inr = (n) => `₹${Number(n || 0).toLocaleString("en-IN")}`;

export default function Dashboard() {
  const [d, setD] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      const get = (t, cols) => supabase.from(t).select(cols);
      const [farms, fields, crops, tasks, expenses, harvests] = await Promise.all([
        get("farms", "id, total_area"), get("fields", "id"), get("crops", "id, status"),
        get("tasks", "id, task_name, due_date, status").neq("status", "Done").order("due_date", { ascending: true }).limit(5),
        get("expenses", "amount"), get("harvests", "quantity"),
      ]);
      const failed = [farms, fields, crops, tasks, expenses, harvests].find((r) => r.error);
      if (failed) { setError(failed.error.message); return; }
      const sum = (r, k) => (r.data || []).reduce((s, x) => s + Number(x[k] || 0), 0);
      setD({
        farms: farms.data.length, area: sum(farms, "total_area"), fields: fields.data.length,
        growing: crops.data.filter((c) => c.status === "Growing").length,
        spent: sum(expenses, "amount"), harvested: sum(harvests, "quantity"), tasks: tasks.data,
      });
    })();
  }, []);

  if (error) return <ErrorNote>{error}</ErrorNote>;
  if (!d) return <div className="grid place-items-center py-24"><Spinner /></div>;

  const stats = [
    { label: "Farms", value: d.farms, href: "/farms" },
    { label: "Fields", value: d.fields, href: "/fields" },
    { label: "Crops growing", value: d.growing, href: "/crops" },
    { label: "Total area", value: `${d.area} ac`, href: "/farms" },
    { label: "Harvested", value: d.harvested, href: "/harvests" },
    { label: "Spent", value: inr(d.spent), href: "/expenses" },
  ];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl font-extrabold">Your farm today</h1>
        <p className="mt-1 text-ink/70">{new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}</p>
      </header>

      {d.farms === 0 && (
        <div className="rounded-2xl bg-leaf p-5 text-white">
          <p className="font-display text-xl font-bold">Start with your first farm</p>
          <p className="mt-1 text-white/85">Then add fields, crops and tasks.</p>
          <Link href="/farms" className="mt-3 inline-flex min-h-11 items-center rounded-xl bg-white px-4 font-semibold text-leaf-dark">Add a farm</Link>
        </div>
      )}

      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {stats.map((s) => (
          <li key={s.label}>
            <Link href={s.href} className="block rounded-2xl border border-line bg-white p-4">
              <p className="font-display text-2xl font-extrabold text-leaf-dark">{s.value}</p>
              <p className="text-sm text-ink/70">{s.label}</p>
            </Link>
          </li>
        ))}
      </ul>

      <section>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">Next tasks</h2>
          <Link href="/tasks" className="min-h-11 content-center font-semibold text-leaf underline">See all</Link>
        </div>
        {d.tasks.length === 0 ? <Empty title="Nothing due" hint="Add a task to stay on top of the season." /> : (
          <ul className="space-y-2">
            {d.tasks.map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-3 rounded-xl border border-line bg-white p-3">
                <span className="min-w-0 break-words font-semibold">{t.task_name}</span>
                <span className="shrink-0 text-sm text-ink/60">{t.due_date || "No date"}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
